var class_board =
[
    [ "Board", "class_board.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "addLeftDecorations", "class_board.html#a0c463f7fbcc70c10eae92713f56ef274", null ],
    [ "addRightDecorations", "class_board.html#aff4a054a115ccf28f8392e0b3c134fd9", null ],
    [ "checkNeigbourSameColor", "class_board.html#aea86fd0e982316a03abc78d042fc6bab", null ],
    [ "getColor", "class_board.html#a7a7523a0be3cf59e602e2a0247a6e6af", null ],
    [ "getHexagon", "class_board.html#a2a89a41c5c0628570c49ed4785473942", null ],
    [ "getOppositeColor", "class_board.html#a2be6c803974a9a09ffa639e7f367b5df", null ],
    [ "initGameBoard", "class_board.html#aa9b6c4c3e948535332797b2213e00c94", null ],
    [ "isEmpty", "class_board.html#a1425229731653f528200521388ccdeec", null ],
    [ "isOnBoard", "class_board.html#a40e354f03cd3996a64f084b2781cd055", null ],
    [ "toString", "class_board.html#a2cf2b2f6adc453bc3b086c9f10c77e11", null ]
];