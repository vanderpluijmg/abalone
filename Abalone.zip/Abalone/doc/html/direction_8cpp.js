var direction_8cpp =
[
    [ "operator<<", "direction_8cpp.html#a42b7ec43e4c1577d4ab21b9f10dc4a17", null ]
];