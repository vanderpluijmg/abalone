var searchData=
[
  ['hexagon_154',['Hexagon',['../class_hexagon.html#ab503950412a7f11dab9c697c45b614a2',1,'Hexagon::Hexagon()'],['../class_hexagon.html#a35322efc6f291fd5f457410191ac3b3a',1,'Hexagon::Hexagon(Color color, int x, int y)']]]
];
