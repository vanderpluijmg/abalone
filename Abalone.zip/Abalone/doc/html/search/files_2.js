var searchData=
[
  ['color_2ehpp_109',['color.hpp',['../color_8hpp.html',1,'']]]
];
