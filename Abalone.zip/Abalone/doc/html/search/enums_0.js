var searchData=
[
  ['color_181',['Color',['../color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1c',1,'color.hpp']]]
];
