var searchData=
[
  ['validatelateralandsamecolor_86',['validateLateralAndSameColor',['../class_game.html#a154b3945ee00bd8006de3d3dbef50bf9',1,'Game']]],
  ['validatelinearandsamecolor_87',['validateLinearAndSameColor',['../class_game.html#a86022b768233f10e78b49f5f8da0dac4',1,'Game']]],
  ['validatemove_88',['validateMove',['../class_game.html#af6ddb6e2bc4419343ec3a428b065145b',1,'Game']]]
];
