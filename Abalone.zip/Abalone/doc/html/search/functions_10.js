var searchData=
[
  ['welcomebanner_175',['welcomeBanner',['../class_t_u_i.html#a233a9f33bbc3d5e2738608cbe765a97e',1,'TUI']]],
  ['wholost_176',['whoLost',['../class_game.html#accf60f159eb52fea94e0e57a9a138102',1,'Game']]],
  ['whoseturn_177',['whoseTurn',['../class_t_u_i.html#a56bd9a7793531d8c9cec79b81c414eb8',1,'TUI']]]
];
