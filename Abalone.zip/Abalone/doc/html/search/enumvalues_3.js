var searchData=
[
  ['outofbound_189',['OUTOFBOUND',['../color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1ca086624d3f2a0973e8f4367794bd5b6c2',1,'color.hpp']]]
];
