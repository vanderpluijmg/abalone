var searchData=
[
  ['black_183',['BLACK',['../color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3',1,'color.hpp']]]
];
