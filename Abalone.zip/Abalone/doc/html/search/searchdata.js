var indexSectionsWithContent =
{
  0: "abcdefghilmnopstvw",
  1: "abdghmpt",
  2: "abcdghmpt",
  3: "abcdfghilmnopstvw",
  4: "dp",
  5: "cd",
  6: "benosw",
  7: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends"
};

