var searchData=
[
  ['directionchoice_182',['directionChoice',['../direction_8h.html#a15c27cb6381450a78e3d8513d7b54ebd',1,'direction.h']]]
];
