var dir_43e4176278cedc844b8407bac23ee66c =
[
    [ "abalonecore.cpp", "abalonecore_8cpp.html", null ],
    [ "abalonecore.h", "abalonecore_8h.html", [
      [ "AbaloneCore", "class_abalone_core.html", "class_abalone_core" ]
    ] ],
    [ "abapro.cpp", "abapro_8cpp.html", null ],
    [ "abapro.h", "abapro_8h.html", [
      [ "MoveUtils", "struct_move_utils.html", "struct_move_utils" ],
      [ "AbaPro", "class_aba_pro.html", null ]
    ] ],
    [ "board.cpp", "board_8cpp.html", null ],
    [ "board.h", "board_8h.html", [
      [ "Board", "class_board.html", "class_board" ]
    ] ],
    [ "color.hpp", "color_8hpp.html", "color_8hpp" ],
    [ "direction.cpp", "direction_8cpp.html", "direction_8cpp" ],
    [ "direction.h", "direction_8h.html", "direction_8h" ],
    [ "game.cpp", "game_8cpp.html", null ],
    [ "game.h", "game_8h.html", [
      [ "Game", "class_game.html", "class_game" ]
    ] ],
    [ "hexagon.hpp", "hexagon_8hpp.html", [
      [ "Hexagon", "class_hexagon.html", "class_hexagon" ]
    ] ],
    [ "position.hpp", "position_8hpp.html", [
      [ "Position", "class_position.html", "class_position" ]
    ] ]
];