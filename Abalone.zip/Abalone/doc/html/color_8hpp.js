var color_8hpp =
[
    [ "Color", "color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1c", [
      [ "WHITE", "color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1ca283fc479650da98250635b9c3c0e7e50", null ],
      [ "BLACK", "color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3", null ],
      [ "EMPTY", "color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1ca2f0d18fc0d0fa4a6cd92dc328501874d", null ],
      [ "OUTOFBOUND", "color_8hpp.html#ab87bacfdad76e61b9412d7124be44c1ca086624d3f2a0973e8f4367794bd5b6c2", null ]
    ] ]
];