var class_game =
[
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "allSameColor", "class_game.html#a35caa1bb63e4c031a54748f707fe8f25", null ],
    [ "applyMove", "class_game.html#af85b77a0b39781cc5b3d8b439a87c877", null ],
    [ "applyMoveLateral", "class_game.html#adff09dabc631622c0263d2649c3071d5", null ],
    [ "applyMoveLinear", "class_game.html#a66aa713f504536896aa21c2005258a4b", null ],
    [ "checkAllCaseEmtpy", "class_game.html#ac97e70d931a3622e8bd730fb3e3ab6d8", null ],
    [ "findDirectionBetween", "class_game.html#a77bb2a31ef00fd1a220592e996403eb0", null ],
    [ "findPositionBetween", "class_game.html#a34c38bdda7254cb98a59cf8c044f3536", null ],
    [ "getBoard", "class_game.html#a6d089ed1bc9e3776d118c00c833db15e", null ],
    [ "loseBall", "class_game.html#a79dc00aaf063f60191f46d7add187467", null ],
    [ "validateLateralAndSameColor", "class_game.html#a154b3945ee00bd8006de3d3dbef50bf9", null ],
    [ "validateLinearAndSameColor", "class_game.html#a86022b768233f10e78b49f5f8da0dac4", null ],
    [ "validateMove", "class_game.html#af6ddb6e2bc4419343ec3a428b065145b", null ],
    [ "whoLost", "class_game.html#accf60f159eb52fea94e0e57a9a138102", null ]
];