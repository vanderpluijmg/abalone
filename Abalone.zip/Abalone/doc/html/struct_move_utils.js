var struct_move_utils =
[
    [ "dir", "struct_move_utils.html#a1df6bdccf8429fe6c89d02ee8f9db74a", null ],
    [ "pos1", "struct_move_utils.html#a1858da4369e74777a5446e825590d7a7", null ],
    [ "pos2", "struct_move_utils.html#adca502cf1ae041433d43bc1c6e22b51a", null ]
];