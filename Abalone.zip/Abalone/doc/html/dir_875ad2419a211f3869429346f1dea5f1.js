var dir_875ad2419a211f3869429346f1dea5f1 =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "tui.cpp", "tui_8cpp.html", null ],
    [ "tui.h", "tui_8h.html", [
      [ "TUI", "class_t_u_i.html", null ]
    ] ]
];