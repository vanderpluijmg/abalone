var class_abalone_core =
[
    [ "AbaloneCore", "class_abalone_core.html#a12106c85bd928bcd20bbe6f5ec4eb4f3", null ],
    [ "finish", "class_abalone_core.html#a61a8ae7f35df4ad9dbecfb48449658fb", null ],
    [ "getEndStatus", "class_abalone_core.html#acc787160d1ca958384b62b97bca9ed41", null ],
    [ "getReturn", "class_abalone_core.html#a1d90fff9a7f01ffcd9f90f6addd4b0a1", null ],
    [ "start", "class_abalone_core.html#a9e306610f0c3d8140a0e3910de9d085b", null ],
    [ "switchTurn", "class_abalone_core.html#a227bb6c08dea9ba09a35203840fac5e2", null ],
    [ "turnPlay", "class_abalone_core.html#ae0450ddfc9819950b8637cd1333baf69", null ]
];