var class_player =
[
    [ "Player", "class_player.html#a0e6411e555691354341782b0d6b1bc09", null ],
    [ "getColor", "class_player.html#abe2b0f82bdfeda3d872c772da40d5140", null ],
    [ "getCurBalls", "class_player.html#a148a5dcfe917ffc64e4f4b61cbeaea22", null ],
    [ "lostBall", "class_player.html#a1fc6cc65a8dc40ee881de46e4ed7e4f9", null ]
];