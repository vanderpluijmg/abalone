#ifndef COLOR_HPP
#define COLOR_HPP

enum Color{
    WHITE,
    BLACK,
    EMPTY,
    OUTOFBOUND
};

#endif // COLOR_HPP